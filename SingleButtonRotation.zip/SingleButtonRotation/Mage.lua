-- Mage rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, mainTree = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.mainTree

local function frostPick()
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")

  if known("Molten Armor") and not has(UnitBuff, "player", "Molten Armor") then
    return "Molten Armor"
  elseif known("Ice Armor") and not known("Molten Armor")
   and not has(UnitBuff, "player", "Ice Armor") then
    return "Ice Armor"
  elseif known("Frost Armor") and not known("Ice Armor") and not known("Molten Armor")
   and not has(UnitBuff, "player", "Frost Armor") then
    return "Frost Armor"
  elseif known("Arcane Intellect") and not has(UnitBuff, "player", "Arcane Intellect")
   and not has(UnitBuff, "player", "Arcane Brilliance") then
    return "Arcane Intellect"
  elseif known("Ice Lance") and hpMax > 0 and hp / hpMax < 0.10 then
    return "Ice Lance"
  elseif known("Deep Freeze") and mine("Frostbite") and ready("Deep Freeze") then
    return "Deep Freeze"
  elseif known("Ice Lance") and mine("Deep Freeze") then
    return "Ice Lance"
  elseif known("Ice Lance") and mine("Frostbite") then
    return "Ice Lance"
  elseif known("Summon Water Elemental") and ready("Summon Water Elemental") then
    return "Summon Water Elemental"
  elseif known("Ice Barrier") and not has(UnitBuff, "player", "Ice Barrier") and ready("Ice Barrier") then
    return "Ice Barrier"
  elseif known("Icy Veins") and ready("Icy Veins") then
    return "Icy Veins"
  elseif known("Frostbolt") then
    return "Frostbolt"
  end
end

local function firePick()
  if known("Molten Armor") and not has(UnitBuff, "player", "Molten Armor") then
    return "Molten Armor"
  elseif known("Ice Armor") and not known("Molten Armor")
   and not has(UnitBuff, "player", "Ice Armor") then
    return "Ice Armor"
  elseif known("Frost Armor") and not known("Ice Armor") and not known("Molten Armor")
   and not has(UnitBuff, "player", "Frost Armor") then
    return "Frost Armor"
  elseif known("Arcane Intellect") and not has(UnitBuff, "player", "Arcane Intellect")
   and not has(UnitBuff, "player", "Arcane Brilliance") then
    return "Arcane Intellect"
  elseif known("Living Bomb") and not mine("Living Bomb") then
    return "Living Bomb"
  elseif known("Pyroblast") and has(UnitBuff, "player", "Hot Streak") then
    return "Pyroblast"
  elseif known("Frostfire Bolt") then
    return "Frostfire Bolt"
  elseif known("Fire Blast") and ready("Fire Blast") then
    return "Fire Blast"
  elseif known("Fireball") then
    return "Fireball"
  end
end

local function arcanePick()
  -- don't interrupt an Arcane Missiles channel
  if UnitChannelInfo("player") == "Arcane Missiles" then
    return nil
  end

  if known("Molten Armor") and not has(UnitBuff, "player", "Molten Armor") then
    return "Molten Armor"
  elseif known("Ice Armor") and not known("Molten Armor")
   and not has(UnitBuff, "player", "Ice Armor") then
    return "Ice Armor"
  elseif known("Frost Armor") and not known("Ice Armor") and not known("Molten Armor")
   and not has(UnitBuff, "player", "Frost Armor") then
    return "Frost Armor"
  elseif known("Arcane Intellect") and not has(UnitBuff, "player", "Arcane Intellect")
   and not has(UnitBuff, "player", "Arcane Brilliance") then
    return "Arcane Intellect"
  end

  local stacks = select(4, UnitDebuff("player", "Arcane Blast")) or 0

  if known("Arcane Missiles") and stacks >= 3 and has(UnitBuff, "player", "Missile Barrage") then
    return "Arcane Missiles"
  elseif known("Arcane Blast") then
    return "Arcane Blast"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.MAGE = function()
  -- mage trees: 1 Arcane, 2 Fire, 3 Frost. Picks the tree with the most points, Fire if none.
  local tree = mainTree()
  if tree == 1 then
    return arcanePick
  elseif tree == 3 then
    return frostPick
  end
  return firePick
end
