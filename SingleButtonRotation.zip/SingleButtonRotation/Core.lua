-- SingleButtonRotation core: shared helpers, the cast function, the next-spell icon and /sbr.
-- Class rotations live in the other files (Druid.lua, Hunter.lua, ...), which load after this one.
-- Each class file registers SBR.routes.<CLASS>, a function that returns the pick function
-- for your current talents or form.

SBR = SBR or {}
SBR.routes = SBR.routes or {}

-- Each pick function decides what to cast but does NOT cast it.
-- It returns: spell name (for the icon/tooltip), cast string, onSelf, stop.
-- The cast string only needs returning when it differs from the spell name.

local function ready(spell)
  local _, d = GetSpellCooldown(spell)
  return d == 0
end

local function known(spell)
  return GetSpellInfo(spell) ~= nil
end

local function has(func, unit, name)
  for i = 1, 40 do
    local n = func(unit, i)
    if not n then return false end
    if n == name then return true end
  end
  return false
end

local function mine(spell)
  local caster = select(8, UnitDebuff("target", spell))
  return caster == "player"
end

local function usable(spell)
  return IsUsableSpell(spell) and true or false
end

local function inRange(spell)
  return IsSpellInRange(spell, "target") == 1
end

-- true if the target is casting or channeling something that can be interrupted
local function interruptible()
  local casting, _, _, _, _, _, _, _, notInterruptible = UnitCastingInfo("target")
  local channeling, _, _, _, _, _, _, chanNotInterruptible = UnitChannelInfo("target")
  return (casting and not notInterruptible) or (channeling and not chanNotInterruptible) or false
end

-- seconds left on a spell's cooldown (0 when ready, or when the spell is unknown)
local function cdLeft(spell)
  local start, duration = GetSpellCooldown(spell)
  if not start or start == 0 then return 0 end
  return math.max(0, start + duration - GetTime())
end

-- cast time in seconds (0 for instant casts or unknown spells)
local function castTime(spell)
  return (select(7, GetSpellInfo(spell)) or 0) / 1000
end

-- seconds left on my own debuff on the target (0 if it is not there)
local function mineLeft(spell)
  for i = 1, 40 do
    local name, _, _, _, _, _, expires, caster = UnitDebuff("target", i)
    if not name then break end
    if name == spell and caster == "player" then
      return math.max(0, (expires or 0) - GetTime())
    end
  end
  return 0
end

-- Returns the talent tree (1-3) where you have the most points spent, or nil with no talents
local function mainTree()
  local best, bestPoints = nil, 0
  for i = 1, 3 do
    local _, _, points = GetTalentTabInfo(i)
    if points and points > bestPoints then
      best, bestPoints = i, points
    end
  end
  return best
end

-- used for specs that don't have a rotation yet: casts nothing
local function noPick() end

-- shared with the class files
SBR.ready = ready
SBR.known = known
SBR.has = has
SBR.mine = mine
SBR.usable = usable
SBR.inRange = inRange
SBR.interruptible = interruptible
SBR.cdLeft = cdLeft
SBR.castTime = castTime
SBR.mineLeft = mineLeft
SBR.mainTree = mainTree
SBR.noPick = noPick

-- Chooses the rotation for your class, talents and form
local function currentPick()
  local route = SBR.routes[select(2, UnitClass("player"))]
  if route then
    return route() or noPick
  end
  return noPick
end

-- set SBRDebug = true (/run SBRDebug=true) to print which spell gets cast
local function act(pick)
  local spell, castStr, onSelf, stop = pick()
  if spell then
    -- stop a cast in progress first (used for interrupts, so Pummel can go off mid-Slam)
    if stop and (UnitCastingInfo("player") or UnitChannelInfo("player")) then
      SpellStopCasting()
    end
    if SBRDebug then print("SBR:", castStr or spell) end
    CastSpellByName(castStr or spell)
  elseif SBRDebug then
    print("SBR: no branch matched")
  end
end

-- The one cast function: used by the key binding, /sbr and clicking the icon
function SBRot() act(currentPick()) end

---------------------------------------------------------------------
-- Next-spell icon (shows what the next button press will cast)
---------------------------------------------------------------------
local f = CreateFrame("Frame", "SBRFrame", UIParent)
f:SetWidth(48)
f:SetHeight(48)
f:SetPoint("CENTER", UIParent, "CENTER", 0, -150)
f:SetMovable(true)
f:EnableMouse(true)
f:SetClampedToScreen(true)
f:RegisterForDrag("LeftButton")
-- draw above the action bar buttons so the icon can sit on top of a bar slot
f:SetFrameStrata("HIGH")

local tex = f:CreateTexture(nil, "ARTWORK")
tex:SetAllPoints(f)
-- trim the icon's built-in edge, like action buttons do
tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)

-- action bar slot border drawn over the icon
local border = f:CreateTexture(nil, "OVERLAY")
border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
border:SetPoint("CENTER", f, "CENTER", 0, -1)
border:SetWidth(48 * 66 / 36)
border:SetHeight(48 * 66 / 36)
-- cooldown sweep drawn over the icon (shows the GCD or the spell's own cooldown)
local cd = CreateFrame("Cooldown", "SBRCooldown", f)
cd:SetAllPoints(f)
local cdStart, cdDur = 0, 0

local current = nil

-- hold Shift and drag to move the icon
f:SetScript("OnDragStart", function(self)
  if IsShiftKeyDown() then
    self.moving = true
    self:StartMoving()
  end
end)
f:SetScript("OnDragStop", function(self)
  self:StopMovingOrSizing()
  local point, _, relPoint, x, y = self:GetPoint()
  SBRDB = SBRDB or {}
  SBRDB.pos = { point, relPoint, x, y }
end)

-- left-click the icon to cast the rotation (like pressing a bar button)
f:SetScript("OnMouseUp", function(self, button)
  if self.moving then
    self.moving = false
  elseif button == "LeftButton" and not IsShiftKeyDown() then
    SBRot()
  end
end)

f:SetScript("OnEnter", function(self)
  GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
  if current then
    local link = GetSpellLink(current)
    if link then
      GameTooltip:SetHyperlink(link)
    else
      GameTooltip:SetText(current)
    end
  else
    GameTooltip:SetText("Nothing to cast")
  end
  GameTooltip:AddLine("Click to cast, Shift+drag to move", 0.6, 0.6, 0.6)
  GameTooltip:Show()
end)
f:SetScript("OnLeave", function() GameTooltip:Hide() end)

local since = 0
f:SetScript("OnUpdate", function(self, e)
  since = since + e
  if since < 0.1 then return end
  since = 0
  current = currentPick()()
  if current then
    tex:SetTexture(select(3, GetSpellInfo(current)))
    tex:SetAlpha(1)
    -- sweep follows the next spell's cooldown, which is the GCD for most spells
    local start, dur = GetSpellCooldown(current)
    start, dur = start or 0, dur or 0
    if dur > 0 and start > 0 then
      if start ~= cdStart or dur ~= cdDur then
        cdStart, cdDur = start, dur
        cd:SetCooldown(start, dur)
      end
    elseif cdDur ~= 0 then
      cdStart, cdDur = 0, 0
      cd:SetCooldown(0, 0)
    end
  else
    tex:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    tex:SetAlpha(0.35)
    if cdDur ~= 0 then
      cdStart, cdDur = 0, 0
      cd:SetCooldown(0, 0)
    end
  end
end)

-- icon size: base 48px multiplied by a slider value (0.5x to 3x)
local BASE = 48
local function applyScale(v)
  SBRDB = SBRDB or {}
  SBRDB.scale = v
  f:SetWidth(BASE * v)
  f:SetHeight(BASE * v)
  border:SetWidth(BASE * v * 66 / 36)
  border:SetHeight(BASE * v * 66 / 36)
end

-- small settings window with a size slider (/sbr config)
local cfg = CreateFrame("Frame", "SBRConfig", UIParent)
cfg:SetWidth(230)
cfg:SetHeight(90)
cfg:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
cfg:SetBackdrop({
  bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
  edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
  tile = true, tileSize = 32, edgeSize = 32,
  insets = { left = 11, right = 12, top = 12, bottom = 11 },
})
cfg:SetMovable(true)
cfg:EnableMouse(true)
cfg:SetClampedToScreen(true)
cfg:RegisterForDrag("LeftButton")
cfg:SetScript("OnDragStart", cfg.StartMoving)
cfg:SetScript("OnDragStop", cfg.StopMovingOrSizing)
cfg:Hide()

local title = cfg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
title:SetPoint("TOP", cfg, "TOP", 0, -14)
title:SetText("SBR icon size")

local close = CreateFrame("Button", nil, cfg, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", cfg, "TOPRIGHT", -2, -2)

local slider = CreateFrame("Slider", "SBRScaleSlider", cfg, "OptionsSliderTemplate")
slider:SetPoint("TOP", cfg, "TOP", 0, -45)
slider:SetWidth(170)
slider:SetMinMaxValues(0.5, 3)
slider:SetValueStep(0.1)
SBRScaleSliderLow:SetText("0.5x")
SBRScaleSliderHigh:SetText("3x")
slider:SetScript("OnValueChanged", function(self, v)
  v = floor(v * 10 + 0.5) / 10
  SBRScaleSliderText:SetText(v .. "x")
  applyScale(v)
end)

-- restore saved position/size/visibility (needs SavedVariables in the .toc to persist)
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self)
  SBRDB = SBRDB or {}
  if SBRDB.pos then
    self:ClearAllPoints()
    self:SetPoint(SBRDB.pos[1], UIParent, SBRDB.pos[2], SBRDB.pos[3], SBRDB.pos[4])
  end
  local v = SBRDB.scale or 1
  slider:SetValue(v)
  applyScale(v)
  if SBRDB.hidden then self:Hide() end
end)

-- /sbr = cast the rotation for your class and spec
-- /sbr hide, /sbr show = toggle the icon
-- /sbr config = open the size slider
-- /sbr scale 1.5 = set the size directly (0.5 to 3)
SLASH_SBR1 = "/sbr"
SlashCmdList["SBR"] = function(msg)
  msg = strlower(msg or "")
  SBRDB = SBRDB or {}
  local cmd, arg = msg:match("^(%S*)%s*(.-)$")
  if cmd == "hide" then
    f:Hide()
    SBRDB.hidden = true
  elseif cmd == "show" then
    f:Show()
    SBRDB.hidden = false
  elseif cmd == "config" then
    if cfg:IsShown() then cfg:Hide() else cfg:Show() end
  elseif cmd == "scale" then
    local n = tonumber(arg)
    if n then
      n = math.max(0.5, math.min(3, n))
      slider:SetValue(n)
    else
      print("SBR: use /sbr scale 1.5 (0.5 to 3)")
    end
  else
    SBRot()
  end
end

-- Key binding label (shown in Key Bindings > AddOns; the binding lives in Bindings.xml)
BINDING_HEADER_SBR = "SingleButtonRotation"
BINDING_NAME_SBR_CAST = "Cast rotation (class and spec)"
