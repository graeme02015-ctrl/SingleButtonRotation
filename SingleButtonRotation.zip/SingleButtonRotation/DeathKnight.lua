-- DeathKnight rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, usable, interruptible = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.usable, SBR.interruptible

-- Death Knight: one shared rotation that picks from the spells you know, like the hunter.
-- Frost knows Obliterate, Unholy knows Scourge Strike and Summon Gargoyle, Blood falls
-- through to Blood Strike. usable() skips a rune spell when its runes aren't available.
local function dkPick()
  local rp = UnitPower("player")

  if known("Blood Presence") and not has(UnitBuff, "player", "Blood Presence") then
    return "Blood Presence"
  elseif known("Mind Freeze") and interruptible() and ready("Mind Freeze")
     and IsSpellInRange("Mind Freeze", "target") ~= 0 then
    return "Mind Freeze"
  elseif known("Icy Touch") and not mine("Frost Fever") and usable("Icy Touch") then
    return "Icy Touch"
  elseif known("Plague Strike") and not mine("Blood Plague") and usable("Plague Strike") then
    return "Plague Strike"
  elseif known("Summon Gargoyle") and rp >= 60 and ready("Summon Gargoyle") then
    return "Summon Gargoyle"
  elseif known("Death Coil") and rp > 60 then
    return "Death Coil"
  elseif known("Scourge Strike") and usable("Scourge Strike") then
    return "Scourge Strike"
  elseif known("Obliterate") and usable("Obliterate") then
    return "Obliterate"
  elseif known("Blood Strike") and usable("Blood Strike") then
    return "Blood Strike"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.DEATHKNIGHT = function()
  return dkPick
end
