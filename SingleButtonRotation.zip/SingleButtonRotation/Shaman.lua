-- Shaman rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, interruptible, cdLeft, castTime, mineLeft, mainTree, noPick = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.interruptible, SBR.cdLeft, SBR.castTime, SBR.mineLeft, SBR.mainTree, SBR.noPick

local function enhancementPick()
  local mana, manaMax = UnitPower("player", 0), UnitPowerMax("player", 0)
  local manaPct = manaMax > 0 and mana / manaMax or 1
  local maelstrom = select(4, UnitBuff("player", "Maelstrom Weapon")) or 0
  local shield = select(4, UnitBuff("player", "Lightning Shield"))
  local _, fireTotem = GetTotemInfo(1)
  local haveFire = fireTotem ~= nil and fireTotem ~= ""

  if known("Wind Shear") and interruptible() and ready("Wind Shear") then
    -- 4th value = stop any cast in progress first
    return "Wind Shear", nil, nil, true
  elseif known("Shamanistic Rage") and manaPct < 0.20 and ready("Shamanistic Rage") then
    return "Shamanistic Rage"
  elseif known("Lightning Bolt") and maelstrom == 5 then
    return "Lightning Bolt"
  elseif known("Flame Shock") and not mine("Flame Shock") and ready("Flame Shock") then
    return "Flame Shock"
  elseif known("Earth Shock") and mine("Stormstrike") and ready("Earth Shock") then
    return "Earth Shock"
  elseif known("Stormstrike") and ready("Stormstrike") then
    return "Stormstrike"
  elseif known("Earth Shock") and ready("Earth Shock") then
    return "Earth Shock"
  elseif known("Magma Totem") and not haveFire then
    return "Magma Totem"
  elseif known("Lightning Shield") and (not shield or shield <= 1) then
    return "Lightning Shield"
  elseif known("Lava Lash") and ready("Lava Lash") then
    return "Lava Lash"
  elseif known("Fire Nova") and haveFire and ready("Fire Nova") then
    return "Fire Nova"
  end
end

local function elementalPick()
  local mana, manaMax = UnitPower("player", 0), UnitPowerMax("player", 0)
  local manaPct = manaMax > 0 and mana / manaMax or 1
  local combat = UnitAffectingCombat("player")
  local _, fireTotem = GetTotemInfo(1)
  local _, airTotem = GetTotemInfo(4)
  local haveFire = fireTotem ~= nil and fireTotem ~= ""
  local haveAir = airTotem ~= nil and airTotem ~= ""
  -- any rank of Magma Totem counts, not just Magma Totem VII
  local magma = haveFire and fireTotem:find("Magma Totem") ~= nil
  -- the macro used Lesser Healing Wave's cast time as the length of the global cooldown
  local gcd = castTime("Lesser Healing Wave")
  if gcd == 0 then gcd = 1.5 end
  -- seconds until Lava Burst is ready, treated as far away when it isn't known
  local lvb = known("Lava Burst") and cdLeft("Lava Burst") or 999
  local fs = mineLeft("Flame Shock")
  -- shock cooldown from talents, copied as is from the macro (Booming Echoes / Reverberation)
  local be = select(5, GetTalentInfo(1, 18)) or 0
  local rev = select(5, GetTalentInfo(1, 6)) or 0
  local fscd = 8 - be - 5 * rev

  if known("Water Shield") and not has(UnitBuff, "player", "Water Shield") then
    return "Water Shield"
  elseif known("Call of the Elements") and combat and not haveAir and ready("Call of the Elements") then
    return "Call of the Elements"
  elseif known("Thunderstorm") and combat and manaPct < 0.40 and ready("Thunderstorm") then
    return "Thunderstorm"
  elseif known("Flame Shock") and fs <= 2 and ready("Flame Shock") then
    return "Flame Shock"
  elseif known("Lava Burst") and ready("Lava Burst") then
    return "Lava Burst"
  elseif lvb > gcd and magma and known("Fire Nova") and ready("Fire Nova") then
    return "Fire Nova"
  elseif lvb > gcd and magma and known("Thunderstorm") and ready("Thunderstorm") then
    return "Thunderstorm"
  elseif known("Chain Lightning") and ready("Chain Lightning") and has(UnitBuff, "player", "Clearcasting")
     and lvb > castTime("Chain Lightning") then
    return "Chain Lightning"
  elseif known("Magma Totem") and lvb > gcd and not haveFire and haveAir then
    return "Magma Totem"
  elseif known("Lightning Bolt") and lvb > castTime("Lightning Bolt") then
    return "Lightning Bolt"
  elseif known("Frost Shock") and lvb > gcd and fs > fscd and ready("Frost Shock") then
    return "Frost Shock"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.SHAMAN = function()
  -- shaman trees: 1 Elemental, 2 Enhancement, 3 Restoration. Elemental if none; Restoration has no rotation.
  local tree = mainTree()
  if tree == 2 then
    return enhancementPick
  elseif tree == 3 then
    return noPick
  end
  return elementalPick
end
