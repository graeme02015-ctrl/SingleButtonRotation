-- Warrior rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, usable, inRange, mainTree = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.usable, SBR.inRange, SBR.mainTree

local function furyPick()
  local rage = UnitPower("player")
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")
  local pct = hpMax > 0 and hp / hpMax or 1

  if known("Bloodrage") and ready("Bloodrage") then
    return "Bloodrage"
  elseif known("Battle Shout") and not has(UnitBuff, "player", "Battle Shout") then
    return "Battle Shout"
  elseif known("Slam") and has(UnitBuff, "player", "Slam!") then
    return "Slam"
  elseif known("Pummel") and UnitCastingInfo("target") and ready("Pummel") then
    -- 4th value = stop any cast in progress first (Slam has a cast time)
    return "Pummel", nil, nil, true
  elseif known("Bloodthirst") and ready("Bloodthirst") then
    return "Bloodthirst"
  elseif known("Whirlwind") and ready("Whirlwind") then
    return "Whirlwind"
  elseif known("Heroic Strike") and rage > 50 then
    return "Heroic Strike"
  elseif known("Execute") and ready("Execute")
     and (pct < 0.20 or has(UnitBuff, "player", "Sudden Death")) then
    return "Execute"
  end
end

local function armsPick()
  local rage = UnitPower("player")
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")
  local pct = hpMax > 0 and hp / hpMax or 1
  local shift = IsShiftKeyDown()
  local sd = has(UnitBuff, "player", "Sudden Death")
  local tfb = has(UnitBuff, "player", "Taste for Blood")
  -- the macro treats a Slam range of exactly 0 as "out of melee range"
  local inMeleeRange = IsSpellInRange("Slam", "target") ~= 0

  if known("Charge") and usable("Charge") and ready("Charge") and inRange("Charge") then
    return "Charge"
  elseif known("Bloodrage") and rage <= 35 and ready("Bloodrage") then
    return "Bloodrage"
  elseif known("Sweeping Strikes") and shift and rage >= 30 and ready("Sweeping Strikes") then
    return "Sweeping Strikes"
  -- Thunder Clap applies Rend on this server; Rend is only cast by hand if that didn't land
  elseif known("Thunder Clap") and inMeleeRange and not mine("Rend")
     and ready("Thunder Clap") and usable("Thunder Clap") then
    return "Thunder Clap"
  elseif known("Rend") and inMeleeRange and not mine("Rend") and rage >= 10 then
    return "Rend"

  -- target above 20% health and in melee range
  elseif pct > 0.20 and inMeleeRange and known("Mortal Strike") and ready("Mortal Strike")
     and not sd and rage >= 30 then
    return "Mortal Strike"
  elseif pct > 0.20 and inMeleeRange and known("Overpower") and ready("Overpower")
     and not sd and tfb and rage >= 5 then
    return "Overpower"
  elseif pct > 0.20 and inMeleeRange and known("Execute") and sd and rage >= 10 then
    return "Execute"
  elseif pct > 0.20 and inMeleeRange and known("Slam") and not UnitIsPlayer("target")
     and not ready("Mortal Strike") and rage >= 15 and not sd and not tfb then
    return "Slam"

  -- target below 20% health and in melee range
  elseif pct < 0.20 and inMeleeRange and known("Overpower") and ready("Overpower")
     and not sd and tfb and rage >= 5 then
    return "Overpower"
  elseif pct < 0.20 and inMeleeRange and known("Execute") and rage >= 10 then
    return "Execute"

  elseif known("Heroic Throw") and ready("Heroic Throw") and inRange("Heroic Throw") then
    return "Heroic Throw"

  -- rage dumps (off the global cooldown), only when nothing above is available
  elseif known("Cleave") and shift and rage >= 50 then
    return "Cleave"
  elseif known("Heroic Strike") and not shift and rage >= 50 and pct > 0.20 then
    return "Heroic Strike"
  end
end

-- Own Sunder Armor on the target: returns stacks and seconds remaining
local function sunder()
  for i = 1, 40 do
    local name, _, _, count, _, _, expires, caster = UnitDebuff("target", i)
    if not name then break end
    if name == "Sunder Armor" and caster == "player" then
      return count or 0, (expires or 0) - GetTime()
    end
  end
  return 0, 0
end

local function protPick()
  local rage = UnitPower("player")
  local myMax = UnitHealthMax("player")
  local myPct = myMax > 0 and UnitHealth("player") / myMax or 1
  local inMeleeRange = inRange("Shield Slam")
  local stacks, remain = sunder()

  if known("Charge") and usable("Charge") and ready("Charge") and inRange("Charge") then
    return "Charge"
  elseif known("Intercept") and usable("Intercept") and ready("Intercept") and inRange("Intercept") then
    return "Intercept"
  elseif known("Shield Bash") and UnitCastingInfo("target") and ready("Shield Bash") then
    return "Shield Bash"
  elseif known("Shield Block") and ready("Shield Block") then
    return "Shield Block"
  elseif known("Enraged Regeneration") and myPct < 0.30 and ready("Enraged Regeneration")
     and usable("Enraged Regeneration") then
    return "Enraged Regeneration"
  elseif known("Shield Wall") and myPct < 0.35 and ready("Shield Wall") then
    return "Shield Wall"
  elseif known("Last Stand") and myPct < 0.30 and ready("Last Stand") then
    return "Last Stand"
  elseif known("Bloodrage") and ready("Bloodrage") then
    return "Bloodrage"
  elseif known("Demoralizing Shout") and inMeleeRange
     and not has(UnitDebuff, "target", "Demoralizing Shout")
     and not has(UnitDebuff, "target", "Demoralizing Roar")
     and not has(UnitDebuff, "target", "Vindication")
     and not has(UnitDebuff, "target", "Curse of Weakness") then
    return "Demoralizing Shout"
  elseif known("Heroic Strike") and has(UnitBuff, "player", "Glyph of Revenge") then
    return "Heroic Strike"
  elseif known("Shield Slam") and ready("Shield Slam") and inMeleeRange then
    return "Shield Slam"
  elseif known("Devastate") and inMeleeRange and (stacks < 5 or remain < 4) then
    return "Devastate"
  elseif known("Revenge") and ready("Revenge") and usable("Revenge") then
    return "Revenge"
  elseif known("Thunder Clap") and ready("Thunder Clap") then
    return "Thunder Clap"
  elseif known("Shockwave") and ready("Shockwave") and inRange("Shockwave") then
    return "Shockwave"
  elseif known("Concussion Blow") and ready("Concussion Blow") and inRange("Concussion Blow") then
    return "Concussion Blow"
  elseif known("Heroic Throw") and ready("Heroic Throw") and inRange("Heroic Throw") then
    return "Heroic Throw"
  elseif known("Heroic Strike") and rage > 79 then
    return "Heroic Strike"
  elseif known("Devastate") and inMeleeRange and rage > 20 then
    return "Devastate"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.WARRIOR = function()
  -- warrior trees: 1 Arms, 2 Fury, 3 Protection. Picks the tree with the most points, Arms if none.
  local tree = mainTree()
  if tree == 2 then
    return furyPick
  elseif tree == 3 then
    return protPick
  end
  return armsPick
end
