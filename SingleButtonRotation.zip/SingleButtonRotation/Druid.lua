-- Druid rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, usable, inRange = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.usable, SBR.inRange

local function enemies()
  local n = 0
  for i = 1, 40 do
    local u = "nameplate" .. i
    if UnitExists(u)
       and UnitCanAttack("player", u)
       and UnitAffectingCombat(u)
       and CheckInteractDistance(u, 3) then
      n = n + 1
    end
  end
  return n
end

local function catPick()
  local p = GetComboPoints("player", "target")
  local myMax = UnitHealthMax("player")
  local myPct = myMax > 0 and UnitHealth("player") / myMax or 1
  
  if known("Mark of the Wild") and not has(UnitBuff, "player", "Mark of the Wild") then
    return "Mark of the Wild", "Mark of the Wild(Rank 1)"
  elseif known("Thorns") and not has(UnitBuff, "player", "Thorns") then
    return "Thorns"
  elseif known("rejuvenation(rank 1)") and myPct < 0.50 and ready("rejuvenation(rank 1)") then
    return "rejuvenation(rank 1)", nil, true
  elseif known("Savage Roar") and p > 0 and not has(UnitBuff, "player", "Savage Roar") then
    return "Savage Roar"
  elseif known("Shred") and has(UnitBuff, "player", "Prowl") then
    return "Shred"
  elseif known("Shred") and has(UnitBuff, "player", "Clearcasting") then
    return "Shred"
  elseif known("Tiger's Fury") and ready("Tiger's Fury") and UnitPower("player") < 30 then
    return "Tiger's Fury"
  elseif known("Rip") and p > 0 and not has(UnitDebuff, "target", "Rip") then
    return "Rip"
  elseif known("Ferocious Bite") and p > 2 then
    return "Ferocious Bite"
  elseif known("Rake") and not has(UnitDebuff, "target", "Rake") then
    return "Rake"
  elseif known("Mangle (cat)") and ready("Mangle (cat)") then
    return "Mangle (cat)"
  elseif known("Claw") and ready("Claw") then
    return "Claw"
  end
end

local function bearPick()
  local rage = UnitPower("player")
  local myMax = UnitHealthMax("player")
  local myPct = myMax > 0 and UnitHealth("player") / myMax or 1
  
  if known("Mark of the Wild") and not has(UnitBuff, "player", "Mark of the Wild") then
    return "Mark of the Wild", "Mark of the Wild(Rank 1)"
  elseif known("Thorns") and not has(UnitBuff, "player", "Thorns") then
    return "Thorns"
  elseif known("rejuvenation(rank 1)") and myPct < 0.50 and ready("rejuvenation(rank 1)") then
    return "rejuvenation(rank 1)", nil, true
  elseif known("Feral Charge - Bear") and usable("Feral Charge - Bear") and ready("Feral Charge - Bear") and inRange("Feral Charge - Bear") then
    return "Feral Charge - Bear"
  elseif known("Faerie Fire (Feral)") and not mine("Faerie Fire (Feral)") and ready("Faerie Fire (Feral)") then
    return "Faerie Fire (Feral)"
  elseif known("Demoralizing Roar") and not mine("Demoralizing Roar") and rage >= 10 then
    return "Demoralizing Roar"
  elseif known("Enrage") and ready("Enrage") then
    return "Enrage"
	  elseif known("Mangle (bear)") and enemies() >= 3 and rage >= 20 then
    return "Mangle (bear)"
  elseif known("Swipe") and enemies() >= 3 and rage >= 20 then
    return "Swipe"
  elseif known("Maul") and rage > 20 then
    return "Maul"
  end
end

local function balPick()
  local mana = UnitPower("player", 0)
  local manaMax = UnitPowerMax("player", 0)
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")
  local pct = hpMax > 0 and hp / hpMax or 1
  local myMax = UnitHealthMax("player")
  local myPct = myMax > 0 and UnitHealth("player") / myMax or 1

  if known("Mark of the Wild") and not has(UnitBuff, "player", "Mark of the Wild")
     and not has(UnitBuff, "player", "Gift of the Wild") then
    return "Mark of the Wild", "Mark of the Wild(rank 1)"
  elseif known("Thorns") and not has(UnitBuff, "player", "Thorns") then
    return "Thorns"
  elseif known("rejuvenation(rank 1)") and myPct < 0.50 and ready("rejuvenation(rank 1)") then
    return "rejuvenation(rank 1)", nil, true
  elseif known("Innervate") and manaMax > 0 and mana / manaMax < 0.45 and ready("Innervate") then
    return "Innervate", "Innervate", true
  elseif known("Faerie Fire") and pct > 0.20
     and not has(UnitDebuff, "target", "Faerie Fire")
     and not has(UnitDebuff, "target", "Faerie Fire (Feral)") then
    return "Faerie Fire"
  elseif known("Moonfire") and not mine("Moonfire") then
    return "Moonfire"
  elseif known("Insect Swarm") and not mine("Insect Swarm") then
    return "Insect Swarm"
  elseif known("Starfire") and has(UnitBuff, "player", "Eclipse (Lunar)") then
    return "Starfire"
  elseif known("Wrath") and has(UnitBuff, "player", "Eclipse (Solar)") then
    return "Wrath"
  elseif known("Wrath") and ready("Wrath") then
    return "Wrath"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.DRUID = function()
  if has(UnitBuff, "player", "Cat Form") then
    return catPick
  elseif has(UnitBuff, "player", "Bear Form") or has(UnitBuff, "player", "Dire Bear Form") then
    return bearPick
  end
  return balPick
end
