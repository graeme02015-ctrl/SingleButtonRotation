-- Paladin rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mainTree, noPick = SBR.ready, SBR.known, SBR.has, SBR.mainTree, SBR.noPick

local function retPick()
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")
  local mana, manaMax = UnitPower("player", 0), UnitPowerMax("player", 0)

  if known("Divine Plea") and ready("Divine Plea") and manaMax > 0 and mana / manaMax < 0.10 then
    return "Divine Plea"
  elseif known("Hammer of Justice") and UnitCastingInfo("target") and ready("Hammer of Justice") then
    return "Hammer of Justice"
  elseif known("Hammer of Wrath") and hpMax > 0 and hp / hpMax < 0.20 and ready("Hammer of Wrath") then
    return "Hammer of Wrath"
  elseif known("Crusader Strike") and ready("Crusader Strike") then
    return "Crusader Strike"
  elseif known("Judgement of Wisdom") and ready("Judgement of Wisdom") then
    return "Judgement of Wisdom"
  elseif known("Divine Storm") and ready("Divine Storm") then
    return "Divine Storm"
  elseif known("Consecration") and ready("Consecration") then
    return "Consecration"
  elseif known("Exorcism") and has(UnitBuff, "player", "The Art of War") and ready("Exorcism") then
    return "Exorcism"
  end
end

local function protPaladinPick()
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")
  local pct = hpMax > 0 and hp / hpMax or 1
  local sacred = select(8, UnitBuff("player", "Sacred Shield")) == "player"

  if known("Hammer of Wrath") and pct < 0.20 and ready("Hammer of Wrath") then
    return "Hammer of Wrath"
  elseif known("Holy Shield") and ready("Holy Shield") then
    return "Holy Shield"
  elseif known("Hammer of the Righteous") and ready("Hammer of the Righteous") then
    return "Hammer of the Righteous"
  elseif known("Shield of Righteousness") and ready("Shield of Righteousness") then
    return "Shield of Righteousness"
  elseif known("Judgement of Wisdom") and ready("Judgement of Wisdom") then
    return "Judgement of Wisdom"
  elseif known("Sacred Shield") and not sacred then
    -- 3rd value = cast on yourself
    return "Sacred Shield", nil, true
  elseif known("Consecration") and ready("Consecration") then
    return "Consecration"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.PALADIN = function()
  -- paladin trees: 1 Holy, 2 Protection, 3 Retribution. Holy has no rotation yet.
  local tree = mainTree()
  if tree == 2 then
    return protPaladinPick
  elseif tree == 3 or tree == nil then
    return retPick
  end
  return noPick
end
