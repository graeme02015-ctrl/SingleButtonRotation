-- Priest rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, mainTree, noPick = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.mainTree, SBR.noPick

local function shadowPick()
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")
  local pct = hpMax > 0 and hp / hpMax or 1
  local mana, manaMax = UnitPower("player", 0), UnitPowerMax("player", 0)
  local manaPct = manaMax > 0 and mana / manaMax or 1

  if known("Shadow Word: Death") and pct < 0.20 and ready("Shadow Word: Death") then
    return "Shadow Word: Death"
  elseif known("Shadowfiend") and manaPct < 0.50 and ready("Shadowfiend") then
    return "Shadowfiend"
  -- Vampiric Embrace is a buff on the priest, not a debuff on the target
  elseif known("Vampiric Embrace") and not has(UnitBuff, "player", "Vampiric Embrace") then
    return "Vampiric Embrace"
  elseif known("Shadow Word: Pain") and not mine("Shadow Word: Pain") then
    return "Shadow Word: Pain"
  elseif known("Inner Focus") and ready("Inner Focus") then
    return "Inner Focus"
  elseif known("Mind Blast") and ready("Mind Blast") then
    return "Mind Blast"
  elseif known("Mind Flay") and not mine("Mind Flay") then
    return "Mind Flay"
  -- low levels without Mind Flay still need something to cast
  elseif known("Smite") and not known("Mind Flay") then
    return "Smite"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.PRIEST = function()
  -- priest trees: 1 Discipline, 2 Holy, 3 Shadow. Only Shadow has a rotation (also used with no talents).
  local tree = mainTree()
  if tree == 3 or tree == nil then
    return shadowPick
  end
  return noPick
end
