-- Warlock rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, mainTree = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.mainTree

local function afflictionPick()
  local hp, hpMax = UnitHealth("target"), UnitHealthMax("target")
  local mana, manaMax = UnitPower("player", 0), UnitPowerMax("player", 0)
  local myMax = UnitHealthMax("player")
  local myPct = myMax > 0 and UnitHealth("player") / myMax or 1

  if known("Haunt") and not mine("Haunt") and ready("Haunt") then
    return "Haunt"
  elseif known("Corruption") and not mine("Corruption") then
    return "Corruption"
  elseif known("Unstable Affliction") and not mine("Unstable Affliction") then
    return "Unstable Affliction"
  elseif known("Curse of Agony") and not mine("Curse of Agony") then
    return "Curse of Agony"
  -- Life Tap costs health, so both Life Tap branches need health above 40%
  elseif known("Life Tap") and myPct > 0.40 and not has(UnitBuff, "player", "Life Tap") then
    return "Life Tap"
  elseif known("Life Tap") and myPct > 0.40 and manaMax > 0 and mana / manaMax < 0.10 then
    return "Life Tap"
  elseif known("Drain Soul") and hpMax > 0 and hp / hpMax < 0.25 then
    return "Drain Soul"
  elseif known("Shadow Bolt") then
    return "Shadow Bolt"
  end
end

local function destroPick()
  if known("Demon Armor") and not has(UnitBuff, "player", "Demon Armor") then
    return "Demon Armor"
  elseif known("Immolate") and not mine("Immolate") then
    return "Immolate"
  elseif known("Shadow Bolt") and not mine("Shadow Mastery") then
    return "Shadow Bolt", "Shadow Bolt(Rank 1)"
  elseif known("Conflagrate") and ready("Conflagrate") then
    return "Conflagrate"
  elseif known("Chaos Bolt") and ready("Chaos Bolt") then
    return "Chaos Bolt"
  elseif known("Incinerate") then
    return "Incinerate"
  end
end

local function demonologyPick()
  local mana, manaMax = UnitPower("player", 0), UnitPowerMax("player", 0)
  local myMax = UnitHealthMax("player")
  local myPct = myMax > 0 and UnitHealth("player") / myMax or 1
  local petAlive = UnitExists("pet") and not UnitIsDead("pet")
  local inMeta = has(UnitBuff, "player", "Metamorphosis")

  -- Life Tap costs health, so only use it when mana is low and health is above 40%
  if known("Life Tap") and myPct > 0.40 and manaMax > 0 and mana / manaMax < 0.15 then
    return "Life Tap"
  elseif known("Demonic Empowerment") and petAlive and ready("Demonic Empowerment") then
    return "Demonic Empowerment"
  elseif known("Metamorphosis") and not inMeta and ready("Metamorphosis") then
    return "Metamorphosis"
  -- Immolation Aura only while in Metamorphosis
  elseif known("Immolation Aura") and inMeta and ready("Immolation Aura") then
    return "Immolation Aura"
  -- Corruption procs Molten Core, so keep it up at all times
  elseif known("Corruption") and not mine("Corruption") then
    return "Corruption"
  elseif known("Immolate") and not mine("Immolate") then
    return "Immolate"
  -- Soul Fire is the filler while Decimation is up (it takes priority over Incinerate)
  elseif known("Soul Fire") and has(UnitBuff, "player", "Decimation") then
    return "Soul Fire"
  -- Molten Core makes Incinerate faster and stronger
  elseif known("Incinerate") and has(UnitBuff, "player", "Molten Core") then
    return "Incinerate"
  elseif known("Shadow Bolt") then
    return "Shadow Bolt"
  -- low levels without Shadow Bolt still need something to cast
  elseif known("Incinerate") then
    return "Incinerate"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.WARLOCK = function()
  -- warlock trees: 1 Affliction, 2 Demonology, 3 Destruction. Affliction or Demonology if it has the
  -- most points, otherwise Destruction (also used with no talents).
  local tree = mainTree()
  if tree == 1 then
    return afflictionPick
  elseif tree == 2 then
    return demonologyPick
  end
  return destroPick
end
