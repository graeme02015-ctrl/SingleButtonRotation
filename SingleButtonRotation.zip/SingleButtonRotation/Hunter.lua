-- Hunter rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has = SBR.ready, SBR.known, SBR.has

-- Melee range check. IsSpellInRange on Raptor Strike/Mongoose Bite wrongly returns 1 at long
-- range on this client, so Wing Clip (a real melee spell) is used instead.
-- Falls back to CheckInteractDistance (about 10 yards) if Wing Clip isn't known.
local function inMelee()
  if known("Wing Clip") then
    return IsSpellInRange("Wing Clip", "target") == 1
  end
  return CheckInteractDistance("target", 3) ~= nil
end

local function markPick()
  local petHurt = UnitExists("pet") and not UnitIsDead("pet")
                  and UnitHealthMax("pet") > 0
                  and UnitHealth("pet") / UnitHealthMax("pet") < 0.50

  if known("Aspect of the Cheetah") and not has(UnitBuff, "player", "Aspect of the Cheetah") then
    return "Aspect of the Cheetah"
  elseif known("Bestial Wrath") and ready("Bestial Wrath") and UnitExists("pet") and not UnitIsDead("pet")
     and not has(UnitBuff, "pet", "Bestial Wrath") then
    return "Bestial Wrath"
  elseif known("Raptor Strike") and inMelee() and ready("Raptor Strike") then
    return "Raptor Strike"
  elseif known("Mongoose Bite") and inMelee() and ready("Mongoose Bite") then
    return "Mongoose Bite"
  elseif known("Black Arrow") and ready("Black Arrow") then
    return "Black Arrow"
  elseif known("Explosive Shot") and ready("Explosive Shot") then
    return "Explosive Shot"
  elseif known("Arcane Shot") and ready("Arcane Shot") then
    return "Arcane Shot"
  elseif known("Silencing Shot") and ready("Silencing Shot") then
    return "Silencing Shot"
  elseif known("Kill Command") and ready("Kill Command") then
    return "Kill Command"
  elseif known("Chimera Shot") and ready("Chimera Shot") then
    return "Chimera Shot"
  elseif known("Aimed Shot") and ready("Aimed Shot") then
    return "Aimed Shot"
  elseif known("Mend Pet") and petHurt and ready("Mend Pet") then
    return "Mend Pet"
  elseif known("Steady Shot") and ready("Steady Shot") then
    return "Steady Shot"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.HUNTER = function()
  return markPick
end
