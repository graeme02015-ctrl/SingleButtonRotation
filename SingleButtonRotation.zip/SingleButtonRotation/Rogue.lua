-- Rogue rotations for SingleButtonRotation (needs Core.lua, which loads first)
local ready, known, has, mine, inRange, interruptible, mainTree = SBR.ready, SBR.known, SBR.has, SBR.mine, SBR.inRange, SBR.interruptible, SBR.mainTree

-- true if the target has any bleed on it (from anyone), which Hunger For Blood needs
local function bleeding()
  return has(UnitDebuff, "target", "Rupture") or has(UnitDebuff, "target", "Garrote")
      or has(UnitDebuff, "target", "Rip") or has(UnitDebuff, "target", "Rake")
      or has(UnitDebuff, "target", "Lacerate") or has(UnitDebuff, "target", "Rend")
      or has(UnitDebuff, "target", "Deep Wounds") or has(UnitDebuff, "target", "Pounce Bleed")
end

local function assassinPick()
  local cp = GetComboPoints("player", "target")
  local energy = UnitPower("player")

  if known("Slice and Dice") and cp > 0 and not has(UnitBuff, "player", "Slice and Dice") then
    return "Slice and Dice"
  elseif known("Hunger For Blood") and not has(UnitBuff, "player", "Hunger For Blood") and bleeding() then
    return "Hunger For Blood"
  -- nobody else is bleeding the target, so apply Rupture to enable Hunger For Blood
  elseif known("Hunger For Blood") and known("Rupture") and cp > 0
     and not has(UnitBuff, "player", "Hunger For Blood") and not bleeding() then
    return "Rupture"
  elseif known("Envenom") and cp >= 4 and (energy >= 80 or not has(UnitBuff, "player", "Envenom")) then
    return "Envenom"
  elseif known("Envenom") and cp >= 4 then
    -- Envenom buff is still up: hold until it fades or energy reaches 80
    return nil
  elseif known("Eviscerate") and cp >= 4 then
    return "Eviscerate"
  elseif known("Mutilate") then
    return "Mutilate"
  elseif known("Sinister Strike") then
    return "Sinister Strike"
  end
end

local function subtletyPick()
  local cp = GetComboPoints("player", "target")

  -- Expose Armor is skipped when a warrior or another rogue already has an armor debuff up
  if known("Expose Armor") and cp > 0
     and not has(UnitDebuff, "target", "Expose Armor")
     and not has(UnitDebuff, "target", "Sunder Armor") then
    return "Expose Armor"
  elseif known("Slice and Dice") and cp > 0 and not has(UnitBuff, "player", "Slice and Dice") then
    return "Slice and Dice"
  elseif known("Rupture") and cp >= 4 and not mine("Rupture") then
    -- Shadowstep first when it is ready, to boost the Rupture
    if known("Shadowstep") and ready("Shadowstep") and inRange("Shadowstep") then
      return "Shadowstep"
    end
    return "Rupture"
  elseif known("Eviscerate") and cp >= 4 then
    return "Eviscerate"
  elseif known("Ghostly Strike") and ready("Ghostly Strike") then
    return "Ghostly Strike"
  elseif known("Hemorrhage") then
    return "Hemorrhage"
  elseif known("Sinister Strike") then
    return "Sinister Strike"
  end
end

-- basic rotation for Combat (and for rogues with no talents yet)
local function combatPick()
  local cp = GetComboPoints("player", "target")
  local canKick = interruptible()

  if known("Kick") and canKick and ready("Kick") and IsSpellInRange("Kick", "target") ~= 0 then
    return "Kick"
  elseif known("Slice and Dice") and cp > 0 and not has(UnitBuff, "player", "Slice and Dice") then
    return "Slice and Dice"
  elseif known("Eviscerate") and cp >= 4 then
    return "Eviscerate"
  elseif known("Sinister Strike") then
    return "Sinister Strike"
  end
end

-- picks the rotation for the current talents/form (called from Core.lua)
SBR.routes.ROGUE = function()
  -- rogue trees: 1 Assassination, 2 Combat, 3 Subtlety. Picks the tree with the most points, Combat if none.
  local tree = mainTree()
  if tree == 1 then
    return assassinPick
  elseif tree == 3 then
    return subtletyPick
  end
  return combatPick
end
